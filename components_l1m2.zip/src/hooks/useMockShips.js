import { useEffect, useState } from "react";

export function useMockShips() {
  const [ships, setShips] = useState([]);
  const [isPending, setIsPending] = useState(true);
  const [isError, setIsError] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    async function loadShips() {
      try {
        setIsPending(true);

        const response = await fetch("/mock.json");

        if (!response.ok) {
          throw new Error("Failed to load mock ships");
        }

        const result = await response.json();

        setShips(result.ships || []);
      } catch (err) {
        setIsError(true);
        setError(err);
      } finally {
        setIsPending(false);
      }
    }

    loadShips();
  }, []);

  return {
    ships,
    isPending,
    isError,
    error,
  };
}
