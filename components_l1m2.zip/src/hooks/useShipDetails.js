// hooks/useShipDetails.js

import { useQueries } from "@tanstack/react-query";
import {
  getPortById,
  getShipById,
  getShipCompanies,
  getShipPhoto,
  getShipPosition,
  getShipSummary,
  getShipVoyage,
} from "@/api/shipApi";

export function useShipDetails({ shipId, portId }) {
  const queries = useQueries({
    queries: [
      {
        queryKey: ["ship", shipId],
        queryFn: () => getShipById(shipId),
        enabled: Boolean(shipId),
        staleTime: 5 * 60 * 1000,
      },
      {
        queryKey: ["ship", shipId, "photo"],
        queryFn: () => getShipPhoto(shipId),
        enabled: Boolean(shipId),
        staleTime: 10 * 60 * 1000,
      },
      {
        queryKey: ["ship", shipId, "position"],
        queryFn: () => getShipPosition(shipId),
        enabled: Boolean(shipId),
        staleTime: 30 * 1000,
      },
      {
        queryKey: ["ship", shipId, "summary"],
        queryFn: () => getShipSummary(shipId),
        enabled: Boolean(shipId),
        staleTime: 5 * 60 * 1000,
      },
      {
        queryKey: ["ship", shipId, "voyage"],
        queryFn: () => getShipVoyage(shipId),
        enabled: Boolean(shipId),
        staleTime: 5 * 60 * 1000,
      },
      {
        queryKey: ["ship", shipId, "companies"],
        queryFn: () => getShipCompanies(shipId),
        enabled: Boolean(shipId),
        staleTime: 10 * 60 * 1000,
      },
      {
        queryKey: ["port", portId],
        queryFn: () => getPortById(portId),
        enabled: Boolean(portId),
        staleTime: 10 * 60 * 1000,
      },
    ],
  });

  const [
    shipQuery,
    photoQuery,
    positionQuery,
    summaryQuery,
    voyageQuery,
    companiesQuery,
    portQuery,
  ] = queries;

  return {
    ship: shipQuery.data,
    photo: photoQuery.data,
    position: positionQuery.data,
    summary: summaryQuery.data,
    voyage: voyageQuery.data,
    companies: companiesQuery.data,
    port: portQuery.data,

    isPending: queries.some((query) => query.isPending),
    isFetching: queries.some((query) => query.isFetching),
    isError: queries.some((query) => query.isError),

    errors: queries
      .filter((query) => query.isError)
      .map((query) => query.error),
  };
}
