import { Pin } from "lucide-react";

import { SidebarTrigger } from "@/components/ui/sidebar";

function SidebarHeader({ isOpen, isPinned, onTogglePin }) {
  return (
    <div className="flex h-14 items-center justify-between border-b px-2">
      <div
        className={[
          "overflow-hidden whitespace-nowrap text-sm font-semibold",
          !isOpen && "w-0 opacity-0",
          isOpen && "opacity-100",
        ].join(" ")}
      >
        Menu
      </div>

      <div className="flex items-center gap-1">
        <SidebarTrigger />

        <button
          type="button"
          onClick={onTogglePin}
          className={[
            "rounded-md p-2 transition-colors",
            isPinned
              ? "bg-primary text-primary-foreground"
              : "text-muted-foreground hover:bg-accent hover:text-accent-foreground",
          ].join(" ")}
          aria-label={isPinned ? "Unpin navigation" : "Pin navigation"}
          title={isPinned ? "Unpin navigation" : "Pin navigation"}
        >
          <Pin className={isPinned ? "size-4 fill-current" : "size-4"} />
        </button>
      </div>
    </div>
  );
}

export default SidebarHeader;
