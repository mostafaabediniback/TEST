import { Anchor, Pin } from "lucide-react";
import {
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
} from "@/components/ui/sidebar";

function NavigationHeader({ isOpen, isPinned, onTogglePin }) {
  return (
    <SidebarMenu>
      <SidebarMenuItem>
        <SidebarMenuButton
          type="button"
          size="lg"
          onClick={onTogglePin}
          tooltip={isPinned ? "Unpin sidebar" : "Pin sidebar"}
          aria-label={isPinned ? "Unpin sidebar" : "Pin sidebar"}
          className="flex items-center gap-2 rounded-lg bg-[#c7f3f8] hover:bg-[#c7f3f8] active:bg-[#c7f3f8]"
        >


          {/* Logo on the right */}
          <Anchor
            aria-hidden="true"
            className={[
              "size-5 shrink-0 text-[#0788c8]",
              isOpen ? "ml-auto" : "mx-auto",
            ].join(" ")}
            strokeWidth={3}
          />


                    {/* Pin on the left */}
          {isOpen && (
            <div
              className={[
                "flex size-8 shrink-0 items-center justify-center rounded-lg",
                "bg-[#0788c8] text-white",
              ].join(" ")}
            >
              <Pin
                aria-hidden="true"
                className={[
                  "size-4 transition-transform",
                  isPinned
                    ? "rotate-[-35deg] fill-current"
                    : "rotate-0",
                ].join(" ")}
                strokeWidth={2.5}
              />
            </div>
          )}
        </SidebarMenuButton>
      </SidebarMenuItem>
    </SidebarMenu>
  );
}

export default NavigationHeader;
