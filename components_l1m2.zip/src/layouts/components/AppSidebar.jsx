import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader as ShadcnSidebarHeader,
} from "@/components/ui/sidebar";

import { NavUser } from "@/components/nav-user";
import NavigationHeader from "./NavigationHeader";
import NavigationLinks from "./NavigationLinks";

const user = {
  name: "shadcn",
  email: "m@example.com",
  avatar: "/avatars/shadcn.jpg",
};

function AppSidebar({
  t,
  isOpen,
  isPinned,
  onTogglePin,
  onMouseEnter,
  onMouseLeave,
  ...props
}) {
  return (
    <Sidebar
      collapsible="icon"
      onMouseEnter={onMouseEnter}
      onMouseLeave={onMouseLeave}
      {...props}
    >
      <ShadcnSidebarHeader>
        <NavigationHeader
          isOpen={isOpen}
          isPinned={isPinned}
          onTogglePin={onTogglePin}
        />
      </ShadcnSidebarHeader>

      <SidebarContent>
        <NavigationLinks t={t} />
      </SidebarContent>

      <SidebarFooter>
        <NavUser user={user} />
      </SidebarFooter>
    </Sidebar>
  );
}

export default AppSidebar;
