import Filters from "@/components/Filters";
import { useDirection } from "@/context/DirectionContext";

export default function RightSidebarContent() {
  const { isRtl } = useDirection();

  return (
    <div className="rounded-md bg-white p-2 shadow-sm">
      <Filters isRtl={isRtl} />
    </div>
  );
}
