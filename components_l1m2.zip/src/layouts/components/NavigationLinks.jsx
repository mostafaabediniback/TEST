import { Home, Map as MapIcon } from "lucide-react";
import { NavLink } from "react-router-dom";

import {
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
} from "@/components/ui/sidebar";

function NavigationLinks({ t }) {
  const links = [
    {
      to: "/",
      label: t("home", "Home"),
      icon: Home,
    },
    {
      to: "/dashboard/:z/:x/:y",
      label: t("map", "Map"),
      icon: MapIcon,
    },
  ];

  return (
    <SidebarGroup  className="flex justify-between">
      <SidebarGroupContent>
        <SidebarMenu>
          {links.map(({ to, label, icon: Icon }) => (
            <SidebarMenuItem key={to}>
              <NavLink to={to} end={to === "/"} className="w-full">
                {({ isActive }) => (
                  <SidebarMenuButton isActive={isActive} tooltip={label}>
                    <Icon />
                    <span>{label}</span>
                  </SidebarMenuButton>
                )}
              </NavLink>
            </SidebarMenuItem>
          ))}
        </SidebarMenu>
      </SidebarGroupContent>

    </SidebarGroup>
  );
}

export default NavigationLinks;
