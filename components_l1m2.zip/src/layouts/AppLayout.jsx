import { ChevronLeft, ChevronRight } from "lucide-react";
import { useState } from "react";
import { useTranslation } from "react-i18next";
import { Outlet, useLocation } from "react-router-dom";

import AppSearch from "@/components/AppSearch";
import {
  SidebarInset,
  SidebarProvider,
  useSidebar,
} from "@/components/ui/sidebar";

import { MapControllerProvider } from "@/context/MapControllerContext";
import { useDirection } from "../context/DirectionContext";
import { useMapInfo } from "../context/MapInfoContext";

import AppSidebar from "./components/AppSidebar";
import MapInfo from "./components/MapInfo";
import RightSidebarContent from "./components/RightSidebarContent";

function LayoutContent() {
  const { t } = useTranslation();
  const { mapInfo } = useMapInfo();
  const { isRtl, direction } = useDirection();
  const { pathname } = useLocation();
  const { open, setOpen } = useSidebar();

const isDashboard =
  pathname === "/dashboard" || pathname.startsWith("/dashboard/");
  const [rightSidebarOpen, setRightSidebarOpen] = useState(true);
  const [leftSidebarPinned, setLeftSidebarPinned] = useState(false);

  const handleSidebarMouseEnter = () => {
    setOpen(true);
  };

  const handleSidebarMouseLeave = () => {
    // Do not close the sidebar if it is pinned
    if (!leftSidebarPinned) {
      setOpen(false);
    }
  };

  const togglePinSidebar = () => {
    setLeftSidebarPinned((previousPinned) => {
      const nextPinned = !previousPinned;

      if (nextPinned) {
        // Pin and keep open
        setOpen(true);
      } else {
        // Unpin and close
        setOpen(false);
      }

      return nextPinned;
    });
  };

  return (
    <div
      dir={direction}
      className="relative flex h-screen w-full overflow-hidden bg-muted/40"
    >
      <AppSidebar
        t={t}
        isOpen={open}
        isPinned={leftSidebarPinned}
        onTogglePin={togglePinSidebar}
        onMouseEnter={handleSidebarMouseEnter}
        onMouseLeave={handleSidebarMouseLeave}
        side={isRtl ? "right" : "left"}
      />

      <SidebarInset className="relative z-0 min-w-0">
        {isDashboard && (
          <div className="fixed left-1/2 top-2 z-[10000] -translate-x-1/2 rounded-md bg-white p-2 shadow-sm">
            <AppSearch />
          </div>
        )}

        <main className="relative z-0 min-h-0 flex-1 overflow-hidden">
          <Outlet />
        </main>
      </SidebarInset>

      {isDashboard && (
        <div
          className={[
            "fixed top-1/2 z-[9999] flex -translate-y-1/2 flex-col items-end gap-4",
            isRtl ? "left-1" : "right-1",
          ].join(" ")}
        >
          <aside
            aria-label={t("mapInformation", "Map information")}
            className={[
              "flex max-w-[calc(100vw-48px)] flex-col",
              "transition-transform duration-300 ease-out",
              rightSidebarOpen
                ? "translate-x-0"
                : isRtl
                  ? "-translate-x-[calc(100%+4px)]"
                  : "translate-x-[calc(100%+4px)]",
            ].join(" ")}
          >
            <RightSidebarContent
              mapInfo={mapInfo}
              onClose={() => setRightSidebarOpen(false)}
            />
          </aside>

          <MapInfo />
        </div>
      )}

      {!rightSidebarOpen && isDashboard && (
        <button
          type="button"
          onClick={() => setRightSidebarOpen(true)}
          aria-label={t("openMapInformation", "Open map information")}
          className={[
            "fixed top-1/2 z-[9999] -translate-y-1/2",
            "rounded-md border bg-background p-2 shadow-md",
            "hover:bg-accent",
            isRtl ? "left-2" : "right-2",
          ].join(" ")}
        >
          {isRtl ? (
            <ChevronRight className="size-4" />
          ) : (
            <ChevronLeft className="size-4" />
          )}
        </button>
      )}
    </div>
  );
}

export default function AppLayout() {
  return (
    <MapControllerProvider>
      <SidebarProvider defaultOpen={false}>
        <LayoutContent />
      </SidebarProvider>
    </MapControllerProvider>
  );
}
