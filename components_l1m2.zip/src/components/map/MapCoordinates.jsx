import { useMapEvents } from "react-leaflet";
import { useMapInfo } from "../../context/MapInfoContext";

export default function MapCoordinates() {
  const { setMapInfo } = useMapInfo();

  useMapEvents({
    mousemove(event) {
      const map = event.target;
      const point = map.latLngToContainerPoint(event.latlng);

      setMapInfo({
        lat: event.latlng.lat,
        lng: event.latlng.lng,
        x: point.x,
        y: point.y,
        z: map.getZoom(),
      });
    },

    zoomend(event) {
      setMapInfo((previous) => ({
        ...previous,
        z: event.target.getZoom(),
      }));
    },
  });

  return null;
}
