import { useEffect } from "react";
import { useMap } from "react-leaflet";
import { useMapInfo } from "@/context/MapInfoContext";

export default function MapInfoUpdater() {
  const map = useMap();
  const { setMapInfo } = useMapInfo();

  useEffect(() => {
    function updateMapInfo() {
      const center = map.getCenter();
      const zoom = Math.floor(map.getZoom());

      const tileSize = map.options.crs.options.tileSize || 256;
      const scale = Math.pow(2, zoom);

      const projectedPoint = map.project(center, zoom);

      let x = Math.floor(projectedPoint.x / tileSize);
      const y = Math.floor(projectedPoint.y / tileSize);

      // Keep x inside the valid world tile range.
      x = ((x % scale) + scale) % scale;

      const nextMapInfo = {
        lat: center.lat,
        lng: center.lng,
        x,
        y,
        z: zoom,
      };

      setMapInfo(nextMapInfo);

      console.log("Current tile:", nextMapInfo);
    }

    updateMapInfo();

    map.on("moveend", updateMapInfo);
    map.on("zoomend", updateMapInfo);

    return () => {
      map.off("moveend", updateMapInfo);
      map.off("zoomend", updateMapInfo);
    };
  }, [map, setMapInfo]);

  return null;
}
