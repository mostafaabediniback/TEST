import { useState } from "react";
import {
  Layers,
  Heart,
  Wind,
  Share2,
  Play,
  Accessibility,
  Navigation,
  Maximize,
  X,
} from "lucide-react";

import { useDirection } from "@/context/DirectionContext";

const filterItems = [
  {
    id: "map",
    icon: Layers,
    title: "Map type",
    options: [
      { label: "Light map", value: "light" },
      { label: "Dark map", value: "dark" },
      { label: "Satellite map", value: "satellite" },
      { label: "Nautical charts", value: "nautical", locked: true },
    ],
  },
  {
    id: "favorites",
    icon: Heart,
    title: "Favorites",
    options: [
      { label: "All favorites", value: "all" },
      { label: "My routes", value: "routes" },
      { label: "Saved places", value: "places" },
    ],
  },
  {
    id: "layers",
    icon: Layers,
    title: "Layers",
    options: [
      { label: "Roads", value: "roads" },
      { label: "Buildings", value: "buildings" },
      { label: "Places", value: "places" },
    ],
  },
  {
    id: "weather",
    icon: Wind,
    title: "Weather",
    options: [
      { label: "Wind", value: "wind" },
      { label: "Waves", value: "waves" },
      { label: "Temperature", value: "temperature" },
    ],
  },
  {
    id: "share",
    icon: Share2,
    title: "Share",
    options: [
      { label: "Share map", value: "share-map" },
      { label: "Copy link", value: "copy-link" },
    ],
  },
  {
    id: "play",
    icon: Play,
    title: "Playback",
    options: [
      { label: "Start playback", value: "start" },
      { label: "Stop playback", value: "stop" },
    ],
  },
  {
    id: "accessibility",
    icon: Accessibility,
    title: "Accessibility",
    options: [
      { label: "Accessible routes", value: "accessible-routes" },
      { label: "High contrast", value: "high-contrast" },
    ],
  },
  {
    id: "navigation",
    icon: Navigation,
    label: "367K",
    title: "Navigation",
    options: [
      { label: "Start navigation", value: "start-navigation" },
      { label: "Route details", value: "route-details" },
    ],
  },
  {
    id: "time",
    label: "9m",
    title: "Time",
    options: [
      { label: "9 minutes", value: "9m" },
      { label: "30 minutes", value: "30m" },
      { label: "1 hour", value: "1h" },
    ],
  },
  {
    id: "fullscreen",
    icon: Maximize,
    title: "Display",
    options: [
      { label: "Fullscreen", value: "fullscreen" },
      { label: "Reset view", value: "reset" },
    ],
  },
];

export default function Filters() {
  const { isRtl } = useDirection();

  const [activeFilter, setActiveFilter] = useState(null);
  const [selectedOptions, setSelectedOptions] = useState({});

  const activeItem = filterItems.find(
    (item) => item.id === activeFilter
  );

  const ActiveIcon = activeItem?.icon;

  const handleFilterClick = (id) => {
    setActiveFilter((current) => (current === id ? null : id));
  };

  const handleOptionClick = (item, option) => {
    if (option.locked) return;

    setSelectedOptions((previous) => ({
      ...previous,
      [item.id]: option.value,
    }));

    setActiveFilter(null);
  };

  return (
    <div className="relative flex items-start">
      {/* Small toolbar */}
      <div className="flex flex-col gap-0.5">
        {filterItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeFilter === item.id;

          return (
            <button
              key={item.id}
              type="button"
              aria-label={item.title}
              aria-pressed={isActive}
              onClick={() => handleFilterClick(item.id)}
              className={[
                "relative flex h-8 w-8 items-center justify-center",
                "rounded-md border bg-white shadow-sm",
                "transition-colors duration-150",
                "focus:outline-none focus:ring-2 focus:ring-blue-500/30",
                isActive
                  ? "border-blue-500 bg-blue-50 text-blue-600"
                  : "border-slate-200 text-slate-500 hover:bg-slate-50 hover:text-slate-800",
                item.label ? "flex-col gap-0" : "",
              ].join(" ")}
            >
              {Icon && <Icon size={14} strokeWidth={1.8} />}

              {item.label && (
                <span className="text-[8px] font-semibold leading-none">
                  {item.label}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Small options panel */}
      {activeItem && (
        <div
          className={[
            "absolute top-0 z-[10000] w-44 overflow-hidden",
            "rounded-md border border-slate-200 bg-white",
            "text-slate-700 shadow-md",
            isRtl ? "left-9" : "right-9",
          ].join(" ")}
        >
          {/* Header */}
          <div className="flex items-center justify-between border-b border-slate-100 px-2 py-1.5">
            <div className="flex items-center gap-1.5">
              {ActiveIcon && (
                <ActiveIcon
                  size={14}
                  strokeWidth={1.8}
                  className="text-slate-500"
                />
              )}

              <span className="text-[11px] font-semibold text-slate-800">
                {activeItem.title}
              </span>
            </div>

            <button
              type="button"
              aria-label="Close options"
              onClick={() => setActiveFilter(null)}
              className="rounded p-0.5 text-slate-400 transition hover:bg-slate-100 hover:text-slate-700"
            >
              <X size={13} />
            </button>
          </div>

          {/* Options */}
          <div className="space-y-0.5 p-1">
            {activeItem.options.map((option) => {
              const isSelected =
                selectedOptions[activeItem.id] === option.value;

              return (
                <button
                  key={option.value}
                  type="button"
                  disabled={option.locked}
                  onClick={() =>
                    handleOptionClick(activeItem, option)
                  }
                  className={[
                    "flex w-full items-center gap-1.5 rounded",
                    "px-2 py-1.5 text-left text-[11px]",
                    "transition-colors",
                    option.locked
                      ? "cursor-not-allowed text-slate-300"
                      : "text-slate-600 hover:bg-slate-50 hover:text-slate-900",
                  ].join(" ")}
                >
                  <span
                    className={[
                      "flex h-3 w-3 items-center justify-center rounded-full border",
                      isSelected
                        ? "border-blue-500"
                        : "border-slate-300",
                    ].join(" ")}
                  >
                    {isSelected && (
                      <span className="h-1.5 w-1.5 rounded-full bg-blue-500" />
                    )}
                  </span>

                  <span>{option.label}</span>

                  {option.locked && (
                    <span className="ml-auto text-[9px] text-slate-400">
                      🔒
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
