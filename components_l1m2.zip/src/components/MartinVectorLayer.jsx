import { useEffect } from "react";
import { useMap } from "react-leaflet";
import L from "leaflet";
import "leaflet.vectorgrid";

function MartinVectorLayer() {
  const map = useMap();

  useEffect(() => {
    const vectorLayer = L.vectorGrid.protobuf(
      "http://localhost:3000/china_shanghai/{z}/{x}/{y}.pbf",
      {
        rendererFactory: L.canvas.tile,

        interactive: true,

        vectorTileLayerStyles: {
          // These names must match the layer IDs in your MBTiles file.
          water: {
            fill: true,
            fillColor: "#9ecae1",
            fillOpacity: 0.8,
            color: "#6baed6",
            weight: 1,
          },

          building: {
            fill: true,
            fillColor: "#d9d9d9",
            fillOpacity: 0.7,
            color: "#999999",
            weight: 0.5,
          },

          transportation: {
            color: "#666666",
            weight: 1.5,
            opacity: 0.8,
          },

          road: {
            color: "#666666",
            weight: 1.5,
            opacity: 0.8,
          },

          // place: {
          //   color: "#d73027",
          //   fillColor: "#d73027",
          //   fill: true,
          //   fillOpacity: 0.8,
          //   radius: 4,
          // },
        },

        getFeatureId: (feature) => {
          return (
            feature.properties?.id ||
            feature.properties?.osm_id ||
            feature.properties?.osmId
          );
        },
      }
    );

    vectorLayer.on("click", (event) => {
      const properties = event.layer?.properties || {};

      console.log("Clicked vector feature:", properties);

      L.popup()
        .setLatLng(event.latlng)
        .setContent(
          `<strong>${properties.name || "Feature"}</strong>`
        )
        .openOn(map);
    });

    vectorLayer.on("mouseover", (event) => {
      event.layer.setStyle({
        weight: 3,
        color: "#f59e0b",
        fillOpacity: 0.9,
      });
    });

    vectorLayer.on("mouseout", (event) => {
      event.layer.setStyle({
        weight: 1,
        color: "#666666",
        fillOpacity: 0.7,
      });
    });

    vectorLayer.addTo(map);

    return () => {
      map.removeLayer(vectorLayer);
    };
  }, [map]);

  return null;
}

export default MartinVectorLayer;
